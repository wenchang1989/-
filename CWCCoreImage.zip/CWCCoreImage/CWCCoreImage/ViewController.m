//
//  ViewController.m
//  CWCCoreImage
//
//  Created by CWC on 15/12/8.
//  Copyright © 2015年 SouFun. All rights reserved.
//

#import "ViewController.h"

#define CONSTROLPANEL_FONTSIZE 12
#define SCREEN_WIDTH [UIScreen mainScreen].bounds.size.width
#define SCREEN_HEIGHT [UIScreen mainScreen].bounds.size.height

@interface ViewController ()<UINavigationControllerDelegate, UIImagePickerControllerDelegate>

{
    UIImagePickerController *_imagePikerController;//系统相片选择控制器
    UIImageView *_imageView;//图片显示控件
    CIContext *_context;//core image 上线文
    CIImage *_image;//我们要编辑的图像
    CIFilter *_colorControsFilter;//色彩滤镜
    
    
}

//@property (nonatomic, strong) UIImagePickerController *imagePikerController;//系统相片选择控制器
//@property (nonatomic, strong) UIImageView *imageView;//图片显示控件
//@property (nonatomic, strong) CIContext *context;//core image 上线文
//@property (nonatomic, strong) CIImage *image;//我们要编辑的图像
//@property (nonatomic, strong) CIFilter *colorControsFilter;//色彩滤镜

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.view.backgroundColor = [UIColor lightGrayColor];
    
//    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    
    
    
    
    
    
    //查看所有内置滤镜效果
//    [self showAllFilters];
  
    //渲染图片
    [self initLayout];
    
}


- (void)initLayout{

    //初始化图片选择器
    _imagePikerController = [[UIImagePickerController alloc] init];
    _imagePikerController.delegate = self;
    
    //创建图片选择控制器
    _imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT-64)];
    _imageView.backgroundColor = [UIColor yellowColor];
    _imageView.contentMode = UIViewContentModeScaleToFill;
    [self.view addSubview:_imageView];
    
    //上方导航按钮
    self.navigationItem.title = @"change color";
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Open" style:UIBarButtonItemStyleDone target:self action:@selector(openPhoto:)];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Save" style:UIBarButtonItemStyleDone target:self action:@selector(savePhoto:)];
    
    //下方的控制面板
    UIView *controlView = [[UIView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT-118-64, SCREEN_WIDTH, 118)];
    [self.view addSubview:controlView];
    
    //饱和度（默认为1，大于1饱和度增加，小于1则降低）
    UILabel *lbstation = [[UILabel alloc] initWithFrame:CGRectMake(10, 10, 60, 25)];
    lbstation.text = @"Saturation";
    lbstation.font = [UIFont systemFontOfSize:CONSTROLPANEL_FONTSIZE];
    [controlView addSubview:lbstation];
    
    UISlider *slbstation = [[UISlider alloc] initWithFrame:CGRectMake(80, 10, SCREEN_WIDTH-80-10, 30)];//注意UISlider高度虽然无法调整。很多朋友会说高度设置为0就可以了，事实上iOS7中，高度设置为0是无法拖动的
    slbstation.tag = 111;
    slbstation.minimumValue = 0;
    slbstation.maximumValue = 2;
    slbstation.value = 1;
    [slbstation addTarget:self action:@selector(changeStaturation:) forControlEvents:UIControlEventValueChanged];
    [controlView addSubview:slbstation];
    
    //亮度（默认为0）
    UILabel *BrightLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 40, 60, 25)];
    BrightLabel.text = @"BrightNess";
    BrightLabel.font = [UIFont systemFontOfSize:CONSTROLPANEL_FONTSIZE];
    [controlView addSubview:BrightLabel];
    
    UISlider *brightSlider = [[UISlider alloc] initWithFrame:CGRectMake(80, 40, SCREEN_WIDTH-80-10, 30)];
    brightSlider.tag = 222;
    brightSlider.minimumValue = -1;
    brightSlider.maximumValue = 1;
    brightSlider.value = 0;
    [brightSlider addTarget:self action:@selector(changeBrightNess:) forControlEvents:UIControlEventValueChanged];
    [controlView addSubview:brightSlider];
    
    //对比度（默认为1）
    UILabel *contrastLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 70, 60, 25)];
    contrastLabel.text = @"Contrast";
    contrastLabel.font = [UIFont systemFontOfSize:CONSTROLPANEL_FONTSIZE];
    [controlView addSubview:contrastLabel];
    
    UISlider *contrastSlider = [[UISlider alloc] initWithFrame:CGRectMake(80, 70, SCREEN_WIDTH-80-10, 30)];
    contrastSlider.tag = 333;
    contrastSlider.minimumValue = 0;
    contrastSlider.maximumValue = 2;
    contrastSlider.value = 1;
    [contrastSlider addTarget:self action:@selector(changeContrast:) forControlEvents:UIControlEventValueChanged];
    
    [controlView addSubview:contrastSlider];
    
    //初始化CIContext
    //创建基于CPU的图像上下文
//    NSNumber *number = [NSNumber numberWithBool:YES];
//    NSDictionary *option = [NSDictionary dictionaryWithObject:number forKey:kCIContextUseSoftwareRenderer];
//    _context = [CIContext contextWithOptions:option];
    
    _context = [CIContext contextWithOptions:nil];//使用GPU渲染，推荐，但注意GPU的CIContext无法跨应用访问，例如直接在UIImagePickerController的完成方法中调用上下文处理就会自动降级为CPU渲染，所以推荐现在完成方法中保存图像，然后再主程序中调用
//    EAGLContext *eglContext = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES1];
//    self.context =[CIContext contextWithEAGLContext:eglContext];//OpenGL优化过的图像上下文
    
    //取得滤镜
    _colorControsFilter = [CIFilter filterWithName:@"CIColorControls"];
    
    
    
}
#pragma mark=打开图片选择器
- (void)openPhoto:(UIBarButtonItem *)sender{

    //打开图片选择器
    [self presentViewController:_imagePikerController animated:YES completion:nil];
    
}
#pragma mark=保存图片
- (void)savePhoto:(UIBarButtonItem *)sender{

    //保存图片到相册
    UIImageWriteToSavedPhotosAlbum(_imageView.image, nil, nil, nil);
    UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:@"Sytem Info" message:@"Save Success !" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    
    [alertVC addAction:action];
    
    [self presentViewController:alertVC animated:YES completion:nil];
    
}

#pragma mark=图片选择器选择图片代理方法
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{

    //关闭图片选择器
    [self dismissViewControllerAnimated:YES completion:nil];
    //取得选择的图片
    UIImage *selectImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    _imageView.image = selectImage;
    
    //初始化CIImage源图像
    _image = [CIImage imageWithCGImage:selectImage.CGImage];
    
    [_colorControsFilter setValue:_image forKey:@"inputImage"];
    
    
    UISlider *slider1 = (UISlider *)[self.view viewWithTag:111];
    if (slider1) {
        slider1.value = 1;
    }
    UISlider *slider2 = (UISlider *)[self.view viewWithTag:222];
    if (slider2) {
        slider2.value = 0;
    }
    UISlider *slider3 = (UISlider *)[self.view viewWithTag:333];
    if (slider3) {
        slider3.value = 1;
    }
    
    
}

#pragma mark=将输出图像设置到UIImageView
- (void)setImage{

    CIImage *outputImage = [_colorControsFilter outputImage];
//    CGContextTranslateCTM(_context, <#CGFloat tx#>, <#CGFloat ty#>)
//    CGContextRotateCTM(], -180);
    CGImageRef temp = [_context createCGImage:outputImage fromRect:[outputImage extent]];
    _imageView.image = [UIImage imageWithCGImage:temp];
    
    CGImageRelease(temp);//释放CGImage对象
    
}
#pragma mark=调整饱和度
- (void)changeStaturation:(UISlider *)sender{

    [_colorControsFilter setValue:[NSNumber numberWithFloat:sender.value] forKey:@"inputSaturation"];
    
    [self setImage];
    
    
}
#pragma mark=亮度
- (void)changeBrightNess:(UISlider *)sender{

    [_colorControsFilter setValue:[NSNumber numberWithFloat:sender.value] forKey:@"inputBrightness"];
    
    [self setImage];
    
}
#pragma mark=调整对比度
- (void)changeContrast:(UISlider *)sender{

    [_colorControsFilter setValue:[NSNumber numberWithFloat:sender.value] forKey:@"inputContrast"];
    
    [self setImage];
    
}

- (UIStatusBarStyle)preferredStatusBarStyle{

    return UIStatusBarStyleLightContent;
    
}

#pragma mark=查看所有内置的滤镜
- (void)showAllFilters{

    NSArray *filterArr = [CIFilter filterNamesInCategory:kCICategoryBuiltIn];
    for (NSString *filterName in filterArr) {
        CIFilter *filter = [CIFilter filterWithName:filterName];
        NSLog(@"\rfilter:%@\rattributes:%@",filterName,[filter attributes]);
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
