//
//  UIImage+ColorToImage.h
//  ChatDemo
//
//  Created by 邱 育良 on 15/7/10.
//  Copyright (c) 2015年 Qiu Yuliang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (ColorToImage)

/**
 *  颜色转图片
 *
 *  @param color 颜色
 *
 *  @return 图片
 */
+ (UIImage *)imageWithColor:(UIColor *)color;

@end
